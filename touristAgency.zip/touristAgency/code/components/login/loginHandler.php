<?php
if($_SERVER["REQUEST_METHOD"==="POST")
{


}
else
{
 header("Location: ../../pages/login.php");
 die();
}
?>
