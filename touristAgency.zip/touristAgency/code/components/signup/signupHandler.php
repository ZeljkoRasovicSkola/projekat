<?php
declare(strict_types=1);

require_once __DIR__ . "../default/db.php";
require_once __DIR__ . "../default/session.php";

if($_SERVER["REQUEST_METHOD"==="POST")
{
 $firstname=trim($_POST["firstname"])??"";
 $lastname=trim($_POST["lastname"])??"";
 $birthdate=trim($_POST["birthdate"])??"";
 $phone=trim($_POST["phone"])??"";
 $address=trim($_POST["address"])??"";
 $city=trim($_POST["city"])??"";
 $email=trim($_POST["email"])??"";
 $password=($_POST["password"])??"";
 $passwordRepeat=($_POST["passwordRepeat"])??"";
 $errors=[];
 
 if(empty($firstname) || empty($lastname) || empty($birthdate) || empty($phone) || empty($address) || empty($city) || empty($email) || empty($password) || empty($passwordRepeat))
 {
  $errors["emptyInput"]="Fill in all fields";
 }

 if(invalidName($firstname))
 {
  $errors["invalidFirstname"]="Choose a proper firstname!";
 }

 if(invalidName($lastname))
 {
  $errors["invalidLastName"]="Choose a proper last name!";
 }

 if(invalidPhone($phone))
 {
  $errors["invalidPhone"]="Choose a proper phone number!";
 }

 if(invalidEmail($email))
 {
  $errors["invalidEmail"]="Choose a proper email!";
 }

 if(existingEmail($email))
 {
  $errors["emailTaken"]="Email is already taken!";
 }

 if(invalidPassword($pass))
 {
  $errors["passMatch"]="Choose a proper password!";
 }

 if(passMatch($pass,$passRepeat))
 {
  $errors["passMatch"]="Passwords do not match!";
 }

 if($errors)
 {
  $_SESSION["errorsAtSignup"]=$errors
  $_SESSION["signupData"]=
  [
   "firstname"=>$firstname,
   "lastname"=>$lastname,
   "birthdate"=>$birthdate,
   "phone"=>$phone,
   "address"=>$address,
   "city"=>$city,
   "email"=>$email,
   "password"=>$password,
   "passwordRepeat"=>$passwordRepeat,
  ]
  header("Location: ../../pages/signup.php");
  die();
 }

 $answer=createUser($firstname,$lastname,$birthdate,$phone,$address,$city,$email,$password,$passwordRepeat);

 if($answer)
 {
   header("Location: ../pages/signup.php?signup=pending");
   die();
 }
 else
 {
  header("Location: ../pages/signup.php?signup=failedToCreateANewUser");
  die();
 }
}
else
{
 header("Location: ../../pages/signup.php");
 die();
}

function invalidName($name)
{
 $result=true;

 if(!(preg_match("/^[a-zA-Z0-9]{3,32}$/",$name)))
  $result=true;
 else
  $result=false;

 return $result;
}

function invalidPhone($phone)
{
 $result=true;

 if(!(preg_match("/^\+[1-9]{1}[0-9]{14,18}$/",$name)))
  $result=true;
 else
  $result=false;

 return $result;
}

function invalidEmail($email)
{
 $result=true;
 
 if(!(filter_var($email,FILTER_VALIDATE_EMAIL)))
  $result=true;
 else
  $result=false;

 return $result;
}

function existingEmail($email)
{
 $sql="SELECT * FROM users WHERE userEmail=:email LIMIT 1;";

 $stmt=$GLOBALS["pdo"]->prepare($sql);
 $stmt->bindParam(":email",$email);
 $stmt->execute();

 $result=$stmt->fetch(PDO::FETCH_ASSOC);
 return $result;
}

function invalidPassword($name)
{
 $result=true;
 
 if(!(preg_match('/^[a-zA-Z0-9]{8,64}$/',$pass)))
  $result=true;
 else
  $result=false;
 
 return $result;
}

function passwordMatch($name)
{
 $result=true;

 if($pass!==$passRepeat)
  $result=true;
 else
  $result=false;
 
 return $result;
}

function createUser($firstname,$lastname,$birthdate,$phone,$address,$city,$email,$password,$passwordRepeat)
{
 $sql="INSERT INTO country(countryName,countryCode) VALUES (); (email,firstname,lastname,phone,password,token) VALUES (:email,:firstname,:lastname,:phone,:pass,:token)";

 $options=['cost'=>12];
 $hashedPass=password_hash($pass,PASSWORD_BCRYPT,$options);

 $stmt=$pdo->prepare($sql);
 $stmt->bindParam(":email",$email);
 $stmt->bindParam(":firstname",$firstName);
 $stmt->bindParam(":lastname",$lastName);
 $stmt->bindParam(":phone",$phone);
 $stmt->bindParam(":pass",$hashedPass);
 $stmt->bindParam(":token",$token);

 if($stmt->execute())
  $result=true;
 else
  $result=false;
 $to="";
 $subject="";
 $message="";
 $headers=array("MIME-Version"=>"1.0","Content-Type"=>"text/html;charset=UTF-8","From"=>"zeljkorasovicskola@gmail.com","Reply-To"=>"zeljkorasovicskola@gmail.com");
 mail($to,$subject,$message,$headers);
}


?>
