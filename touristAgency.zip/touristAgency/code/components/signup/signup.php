   <section class="bg flexCenter">
    <div class="border">
     <div class="flexCenter">
      <h2>Sign up</h2>
     </div>
     <form method="POST" action="../components/sigup/signupHandler.php">
      <div>
       <label for="Firstname">Firstname:</label>
       <br>
       <input type="text" name="firstname" placeholder="Enter your firstname" id="Firstname" required class="input">
      </div>
      <br>
      <div>
       <label for="LastName">Lastname:</label>
       <br>
       <input type="text" name="lastname" placeholder="Enter your lastname" id="LastName" required class="input">
      </div>
      <br>
      <div class="flex">
       <div class="flexLeft">
        <label for="BirthdateDate" id="BirthdateDateLabel">Birthdate:</label>
        <label for="BirthdateText" id="BirthdateTextLabel" class="hide">Birthdate:</label>
       </div>
       <div class="flexRight inputDots">
        <input type="radio" name="inputTypeBirthDate" onclick="switchInput();" id="selectTypeBirthDate" checked>
        <input type="radio" name="inputTypeBirthDate" onclick="switchInput();" id="inputTextTypeBirthDate">
       </div>
      </div>
      <div>
       <input type="date" name="birthdate" id="BirthdateDate" class="input">
       <input type="text" name="birthdate" placeholder="Enter your birthdate" id="BirthdateText" class="input hide">
      </div>
      <br>
      <div class="flex">
       <div class="flexLeft">
        <label for="CountrySelect" id="CountrySelectLabel">Country:</label>
        <label for="CountryText" id="CountryTextLabel" class="hide">Country:</label>
       </div>
       <div class="flexRight inputDots">
        <input type="radio" name="inputTypeCountry" onclick="switchInput();" id="selectTypeCountry" checked>
        <input type="radio" name="inputTypeCountry" onclick="switchInput();" id="inputTextTypeCountry">
       </div>
      </div>
      <div>
       <select name="country" placeholder="Country" id="CountrySelect" class="select">
        <?php
         echo'<option value="" disable>Country</option>';
        ?>
       </select> 
       <div class="upBreak customSelect">
        <div class="customSelectSelectedItem">
         <input type="text" name="country" placeholder="Country" value="" readonly id="selectValue" class="input">
        </div>
        <div class="customSelectDropDown">
         <div class="customSelectSearch">
          <input type="text" name="" placeholder="" class="input">
         </div>
         <div class="customSelectItems">
          <?php
           echo'<div class="customSelectItem active">Country</div>';
           echo'<div class="customSelectItem">Countries</div>';
          ?>
         </div>
        </div>
       </div>
       <input type="text" name="country" placeholder="Enter your country" list="listOfCountries" id="CountryText" class="input hide">
       <datalist id="listOfCountries">
        <?php
         echo'<option value="" disable>Country</option>';
        ?>
       </datalist>
      </div>
      <div>
       <label for="CountryCodeText" id="CountryCodeLabel" class="upBreak hide">Country code:</label>
       <input type="text" name="countryCode" placeholder="Enter your country code" list="listOfCountryCodes" id="CountryCodeText" class="input hide">
       <datalist id="listOfCountryCodes">
        <?php
         echo'<option value="" disable>Country code</option>';
        ?>
       </datalist>
      </div>
      <br>
      <div class="flex">
       <div class="flexLeft">
        <label for="CitySelect" id="CitySelectLabel">City:</label>
        <label for="CityText" id="CityTextLabel" class="hide">City:</label>
       </div>
       <div class="flexRight inputDots">
        <input type="radio" name="inputTypeCity" onclick="switchInput();" id="selectTypeCity" checked>
        <input type="radio" name="inputTypeCity" onclick="switchInput();" id="inputTextTypeCity">
       </div>
      </div>
      <div>
       <select name="city" required id="CitySelect" class="select">
        <?php
         echo'<option value="none" disable>City</option>';
        ?>
       </select>
       <input type="text" name="city" placeholder="Enter your city" list="listOfCities" id="CityText" class="input hide">
       <datalist id="listOfCities">
        <?php
         echo'<option value="" disable>City</option>';
        ?>
       </datalist>
      </div>
      <div>
       <label for="PostalCodeText" id="PostalCodeLabel" class="upBreak hide">Postal code:</label>
       <input type="text" name="Postalcode" placeholder="Enter your postal code" list="listOfPostalCodes" id="PostalCodeText" class="input hide">
       <datalist id="listOfPostalCodes">
        <?php
         echo'<option value="" disable>Postal code</option>';
        ?>
       </datalist>
      </div>
      <br>
      <div>
       <label for="Address">Address:</label>
       <br>
       <input type="text" name="address" placeholder="Enter your address" required id="Address" class="input">
      </div>
      <br>
      <div class="flex">
       <div class="flexLeft">
        <label for="PhoneTextPart" id="PhoneTextPartLabel">Phone:</label>
       </div>
       <div class="flexRight inputDots">
        <input type="radio" name="inputTypePhone" onclick="switchInput();" id="selectTypePhone" checked>
        <input type="radio" name="inputTypePhone" onclick="switchInput();" id="inputTextTypePhone">
       </div>
      </div>
      <div class="flex">
       <select name="countryCode" required id="CountryCode" class="input">
        <?php
         echo'<option value="none" disable>Flag</option>';
        ?>
       </select>
       <input type="text" name="phone" placeholder="Enter your phone" required id="PhoneTextPart" class="input">
      </div>
      <br>
      <div>
       <label for="Email">Email:</label>
       <br>
       <input type="email" name="email" placeholder="Enter your email" required id="Email" class="input">
      </div>
      <br>
      <div>
       <label for="Password">Password:</label>
       <br>
       <input type="password" name="password" placeholder="Enter your password" required id="Password" class="input">
      </div>
      <br>
      <div>
       <label for="PasswordRepeat">Password repeat:</label>
       <br>
       <input type="password" name="passwordRepeat" placeholder="Enter your password" required id="PasswordRepeat" class="input">
      </div>
      <br>
      <br>
      <br>
      <div class="flexCenter">
       <input type="submit" name="submit" value="Sign up" class="button">
      </div>
      <br>
     </form>
    </div>
   </section>
   <script src="../components/signup/signup.js" defer></script>
