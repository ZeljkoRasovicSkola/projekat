<?php
 $title="Home page";
 $slider=1;
 require '../components/head/head.php';
?>
 <body>
 <?php require '../components/nav/nav.php';?>
  <main>
   <?php require '../components/slider/slider.php';?>
  </main>
 </body>
</html>
